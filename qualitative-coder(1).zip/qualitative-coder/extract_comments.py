#!/usr/bin/env python3
"""
Extract existing comments from Word documents (.docx)
Outputs to JSON or imports directly into the qualitative coder database.

Usage:
    python extract_comments.py                    # Extract from all docs in data/
    python extract_comments.py document.docx     # Extract from specific file
    python extract_comments.py --import          # Import comments as annotations
"""

import argparse
import json
import sqlite3
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
from datetime import datetime

# XML namespaces used in Word documents
NAMESPACES = {
    'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
    'w14': 'http://schemas.microsoft.com/office/word/2010/wordml',
    'w15': 'http://schemas.microsoft.com/office/word/2012/wordml'
}

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / 'data'
DB_PATH = BASE_DIR / 'project.db'


def extract_comments_from_docx(docx_path):
    """Extract all comments from a .docx file."""
    comments = []
    
    try:
        with zipfile.ZipFile(docx_path, 'r') as zf:
            # Check if comments.xml exists
            if 'word/comments.xml' not in zf.namelist():
                return comments
            
            # Parse comments.xml
            with zf.open('word/comments.xml') as f:
                tree = ET.parse(f)
                root = tree.getroot()
            
            # Parse document.xml for comment ranges
            with zf.open('word/document.xml') as f:
                doc_tree = ET.parse(f)
                doc_root = doc_tree.getroot()
            
            # Extract comment metadata
            comment_data = {}
            for comment in root.findall('.//w:comment', NAMESPACES):
                comment_id = comment.get('{%s}id' % NAMESPACES['w'])
                author = comment.get('{%s}author' % NAMESPACES['w'], 'Unknown')
                date = comment.get('{%s}date' % NAMESPACES['w'], '')
                
                # Get comment text
                text_parts = []
                for p in comment.findall('.//w:t', NAMESPACES):
                    if p.text:
                        text_parts.append(p.text)
                comment_text = ''.join(text_parts)
                
                comment_data[comment_id] = {
                    'id': comment_id,
                    'author': author,
                    'date': date,
                    'text': comment_text,
                    'referenced_text': ''
                }
            
            # Find comment ranges in document to get referenced text
            # This is complex because comments span multiple runs
            comment_ranges = {}
            
            # Track comment range starts and ends
            for elem in doc_root.iter():
                tag = elem.tag.split('}')[1] if '}' in elem.tag else elem.tag
                
                if tag == 'commentRangeStart':
                    comment_id = elem.get('{%s}id' % NAMESPACES['w'])
                    if comment_id:
                        comment_ranges[comment_id] = {'start_found': True, 'text_parts': []}
                
                elif tag == 'commentRangeEnd':
                    comment_id = elem.get('{%s}id' % NAMESPACES['w'])
                    if comment_id and comment_id in comment_ranges:
                        comment_ranges[comment_id]['end_found'] = True
                
                elif tag == 't':
                    # Check if we're inside any comment range
                    for cid, range_info in comment_ranges.items():
                        if range_info.get('start_found') and not range_info.get('end_found'):
                            if elem.text:
                                range_info['text_parts'].append(elem.text)
            
            # Combine referenced text
            for cid, range_info in comment_ranges.items():
                if cid in comment_data:
                    comment_data[cid]['referenced_text'] = ''.join(range_info.get('text_parts', []))
            
            comments = list(comment_data.values())
    
    except zipfile.BadZipFile:
        print(f"  ⚠️  Not a valid docx file: {docx_path}")
    except Exception as e:
        print(f"  ⚠️  Error processing {docx_path}: {e}")
    
    return comments


def extract_all_comments(directory=None, output_file=None):
    """Extract comments from all Word documents in a directory."""
    if directory is None:
        directory = DATA_DIR
    
    directory = Path(directory)
    all_comments = {}
    
    print(f"\n📂 Scanning directory: {directory}")
    print("-" * 50)
    
    docx_files = list(directory.glob('*.docx'))
    
    if not docx_files:
        print("  No .docx files found.")
        return all_comments
    
    for docx_path in docx_files:
        print(f"\n📄 {docx_path.name}")
        comments = extract_comments_from_docx(docx_path)
        
        if comments:
            all_comments[docx_path.name] = comments
            print(f"   Found {len(comments)} comments")
            
            for c in comments[:3]:  # Show first 3
                preview = c['text'][:50] + '...' if len(c['text']) > 50 else c['text']
                print(f"   • [{c['author']}] {preview}")
            
            if len(comments) > 3:
                print(f"   ... and {len(comments) - 3} more")
        else:
            print("   No comments found")
    
    print("\n" + "-" * 50)
    total = sum(len(c) for c in all_comments.values())
    print(f"📊 Total: {total} comments from {len(all_comments)} documents")
    
    # Save to JSON if output file specified
    if output_file:
        output_path = Path(output_file)
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(all_comments, f, ensure_ascii=False, indent=2)
        print(f"\n💾 Saved to: {output_path}")
    
    return all_comments


def import_comments_to_db(all_comments):
    """Import extracted comments as annotations in the database."""
    if not all_comments:
        print("No comments to import.")
        return
    
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    
    # Ensure "Imported Comment" label exists
    cursor = conn.execute(
        "SELECT id FROM labels WHERE name = ?", 
        ("Imported Comment",)
    )
    row = cursor.fetchone()
    
    if row:
        label_id = row['id']
    else:
        cursor = conn.execute(
            "INSERT INTO labels (name, color, description) VALUES (?, ?, ?)",
            ("Imported Comment", "#B8860B", "Comments imported from Word documents")
        )
        label_id = cursor.lastrowid
    
    imported_count = 0
    
    for filename, comments in all_comments.items():
        # Get document ID
        cursor = conn.execute(
            "SELECT id, content FROM documents WHERE filename = ?",
            (filename,)
        )
        doc = cursor.fetchone()
        
        if not doc:
            print(f"  ⚠️  Document not in database: {filename}")
            continue
        
        doc_id = doc['id']
        doc_content = doc['content'] or ''
        
        for comment in comments:
            referenced_text = comment.get('referenced_text', '')
            comment_text = comment.get('text', '')
            author = comment.get('author', 'Unknown')
            
            if not referenced_text:
                continue
            
            # Find position in document
            start_offset = doc_content.find(referenced_text)
            if start_offset == -1:
                # Try with whitespace normalized
                normalized_ref = ' '.join(referenced_text.split())
                normalized_doc = ' '.join(doc_content.split())
                start_offset = normalized_doc.find(normalized_ref)
                if start_offset == -1:
                    continue
            
            end_offset = start_offset + len(referenced_text)
            
            # Create annotation
            note = f"[Imported from Word - Author: {author}]"
            
            conn.execute('''
                INSERT INTO annotations 
                (document_id, label_id, start_offset, end_offset, highlighted_text, comment, note)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (doc_id, label_id, start_offset, end_offset, referenced_text, comment_text, note))
            
            imported_count += 1
    
    conn.commit()
    conn.close()
    
    print(f"\n✅ Imported {imported_count} comments as annotations")


def main():
    parser = argparse.ArgumentParser(
        description='Extract comments from Word documents'
    )
    parser.add_argument(
        'file', 
        nargs='?', 
        help='Specific .docx file to process (default: all files in data/)'
    )
    parser.add_argument(
        '-o', '--output',
        help='Output JSON file path'
    )
    parser.add_argument(
        '--import',
        dest='do_import',
        action='store_true',
        help='Import comments as annotations in the database'
    )
    
    args = parser.parse_args()
    
    print("\n" + "=" * 60)
    print("  Word Document Comment Extractor")
    print("=" * 60)
    
    if args.file:
        # Single file mode
        file_path = Path(args.file)
        if not file_path.exists():
            print(f"Error: File not found: {file_path}")
            return
        
        comments = extract_comments_from_docx(file_path)
        all_comments = {file_path.name: comments} if comments else {}
    else:
        # Directory mode
        all_comments = extract_all_comments(
            DATA_DIR, 
            args.output or (BASE_DIR / 'extracted_comments.json')
        )
    
    if args.do_import:
        print("\n📥 Importing to database...")
        import_comments_to_db(all_comments)
    
    print("\n" + "=" * 60 + "\n")


if __name__ == '__main__':
    main()
