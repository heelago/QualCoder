#!/bin/bash

# Colors for pretty output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color
BOLD='\033[1m'

clear

echo ""
echo -e "${PURPLE}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${PURPLE}║                                                          ║${NC}"
echo -e "${PURPLE}║${NC}             ${BOLD}מקודד איכותני - Qualitative Coder${NC}            ${PURPLE}║${NC}"
echo -e "${PURPLE}║                                                          ║${NC}"
echo -e "${PURPLE}║${NC}                    Setup Wizard v1.0                     ${PURPLE}║${NC}"
echo -e "${PURPLE}║                                                          ║${NC}"
echo -e "${PURPLE}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if Python 3 is installed
echo -e "${BLUE}[1/4]${NC} Checking for Python..."
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
    PIP_CMD="pip3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
    PIP_CMD="pip"
else
    echo ""
    echo -e "${RED}⚠️  Python is not installed!${NC}"
    echo ""
    
    # Check OS and provide instructions
    if [[ "$OSTYPE" == "darwin"* ]]; then
        echo "  On macOS, you can install Python with:"
        echo "  1. Download from: https://www.python.org/downloads/"
        echo "  2. Or use Homebrew: brew install python3"
    else
        echo "  On Linux, install Python with:"
        echo "  Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
        echo "  Fedora: sudo dnf install python3 python3-pip"
    fi
    echo ""
    echo "  After installing Python, run this script again."
    exit 1
fi
echo -e "      ${GREEN}✓${NC} Python found! ($($PYTHON_CMD --version))"

# Create virtual environment if not exists
echo -e "${BLUE}[2/4]${NC} Setting up environment..."
if [ ! -d "venv" ]; then
    echo "      Creating virtual environment..."
    $PYTHON_CMD -m venv venv
fi
echo -e "      ${GREEN}✓${NC} Environment ready!"

# Activate virtual environment
source venv/bin/activate

# Install requirements
echo -e "${BLUE}[3/4]${NC} Installing dependencies..."
pip install flask openpyxl python-docx --quiet 2>/dev/null
echo -e "      ${GREEN}✓${NC} Dependencies installed!"

# Create folders
echo -e "${BLUE}[4/4]${NC} Preparing folders..."
mkdir -p data exports
echo -e "      ${GREEN}✓${NC} Folders ready!"

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                          ║${NC}"
echo -e "${GREEN}║${NC}                    ${BOLD}✓ Setup Complete!${NC}                     ${GREEN}║${NC}"
echo -e "${GREEN}║                                                          ║${NC}"
echo -e "${GREEN}║${NC}   Put your documents in the ${BOLD}data${NC} folder                 ${GREEN}║${NC}"
echo -e "${GREEN}║${NC}   The app will open in your browser automatically        ${GREEN}║${NC}"
echo -e "${GREEN}║                                                          ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Open data folder for user
if [[ "$OSTYPE" == "darwin"* ]]; then
    open "data"
else
    xdg-open "data" 2>/dev/null || true
fi

# Function to open browser
open_browser() {
    sleep 2
    URL="http://localhost:5000"
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open "$URL"
    elif command -v xdg-open &> /dev/null; then
        xdg-open "$URL"
    elif command -v gnome-open &> /dev/null; then
        gnome-open "$URL"
    fi
}

# Start browser in background
open_browser &

echo "  Starting server..."
echo "  (Press Ctrl+C to stop)"
echo ""
echo "  ────────────────────────────────────────────────────────────"
echo ""

# Run the app
$PYTHON_CMD app.py

# If we get here, server has stopped
echo ""
echo "  Server stopped."
