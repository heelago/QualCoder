#!/usr/bin/env python3
"""
Qualitative Data Coder - Local tool for qualitative analysis
Supports: text highlighting, overlapping labels, comments, notes, Excel export
"""

import os
import json
import sqlite3
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file
import hashlib

app = Flask(__name__)
app.config['SECRET_KEY'] = 'local-qualitative-coder-2024'

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / 'data'
EXPORTS_DIR = BASE_DIR / 'exports'
DB_PATH = BASE_DIR / 'project.db'

# Ensure directories exist
DATA_DIR.mkdir(exist_ok=True)
EXPORTS_DIR.mkdir(exist_ok=True)

def get_db():
    """Get database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database with schema."""
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY,
            filename TEXT UNIQUE NOT NULL,
            filepath TEXT NOT NULL,
            content TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS labels (
            id INTEGER PRIMARY KEY,
            name TEXT UNIQUE NOT NULL,
            color TEXT NOT NULL DEFAULT '#FFD700',
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS annotations (
            id INTEGER PRIMARY KEY,
            document_id INTEGER NOT NULL,
            label_id INTEGER,
            start_offset INTEGER NOT NULL,
            end_offset INTEGER NOT NULL,
            highlighted_text TEXT NOT NULL,
            comment TEXT,
            note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (document_id) REFERENCES documents(id),
            FOREIGN KEY (label_id) REFERENCES labels(id)
        );
        
        CREATE INDEX IF NOT EXISTS idx_annotations_doc ON annotations(document_id);
        CREATE INDEX IF NOT EXISTS idx_annotations_label ON annotations(label_id);
    ''')
    
    # Insert default labels if none exist
    cursor = conn.execute('SELECT COUNT(*) FROM labels')
    if cursor.fetchone()[0] == 0:
        default_labels = [
            ('Theme 1', '#FF6B6B', 'Primary theme'),
            ('Theme 2', '#4ECDC4', 'Secondary theme'),
            ('Theme 3', '#45B7D1', 'Tertiary theme'),
            ('Quote', '#96CEB4', 'Important quote'),
            ('Question', '#FFEAA7', 'Question or uncertainty'),
            ('Contradiction', '#DDA0DD', 'Contradiction or tension'),
            ('Pattern', '#98D8C8', 'Recurring pattern'),
            ('Insight', '#F7DC6F', 'Key insight'),
        ]
        conn.executemany(
            'INSERT INTO labels (name, color, description) VALUES (?, ?, ?)',
            default_labels
        )
    conn.commit()
    conn.close()

def extract_text_from_file(filepath):
    """Extract text from various file formats."""
    filepath = Path(filepath)
    ext = filepath.suffix.lower()
    
    try:
        if ext == '.txt':
            return filepath.read_text(encoding='utf-8')
        
        elif ext == '.docx':
            try:
                from docx import Document
                doc = Document(filepath)
                return '\n\n'.join([para.text for para in doc.paragraphs])
            except ImportError:
                # Fallback: use pandoc
                import subprocess
                result = subprocess.run(
                    ['pandoc', str(filepath), '-t', 'plain'],
                    capture_output=True, text=True
                )
                return result.stdout
        
        elif ext == '.pdf':
            try:
                import subprocess
                result = subprocess.run(
                    ['pdftotext', str(filepath), '-'],
                    capture_output=True, text=True
                )
                return result.stdout
            except:
                return f"[PDF extraction failed for {filepath.name}]"
        
        elif ext in ['.md', '.markdown']:
            return filepath.read_text(encoding='utf-8')
        
        elif ext == '.rtf':
            import subprocess
            result = subprocess.run(
                ['pandoc', str(filepath), '-t', 'plain'],
                capture_output=True, text=True
            )
            return result.stdout
        
        else:
            # Try reading as plain text
            return filepath.read_text(encoding='utf-8', errors='replace')
    
    except Exception as e:
        return f"[Error extracting text: {str(e)}]"

def scan_documents():
    """Scan data directory and add new documents to database."""
    conn = get_db()
    supported_extensions = {'.txt', '.docx', '.pdf', '.md', '.markdown', '.rtf'}
    
    for filepath in DATA_DIR.iterdir():
        if filepath.suffix.lower() in supported_extensions and filepath.is_file():
            # Check if already in database
            cursor = conn.execute(
                'SELECT id FROM documents WHERE filename = ?',
                (filepath.name,)
            )
            if cursor.fetchone() is None:
                content = extract_text_from_file(filepath)
                conn.execute(
                    'INSERT INTO documents (filename, filepath, content) VALUES (?, ?, ?)',
                    (filepath.name, str(filepath), content)
                )
    
    conn.commit()
    conn.close()

@app.route('/')
def index():
    """Main page with document list."""
    scan_documents()
    conn = get_db()
    
    documents = conn.execute('''
        SELECT d.*, COUNT(a.id) as annotation_count
        FROM documents d
        LEFT JOIN annotations a ON d.id = a.document_id
        GROUP BY d.id
        ORDER BY d.filename
    ''').fetchall()
    
    labels = conn.execute('SELECT * FROM labels ORDER BY name').fetchall()
    
    stats = conn.execute('''
        SELECT 
            COUNT(DISTINCT document_id) as docs_with_annotations,
            COUNT(*) as total_annotations
        FROM annotations
    ''').fetchone()
    
    conn.close()
    return render_template('index.html', 
                         documents=documents, 
                         labels=labels,
                         stats=stats)

@app.route('/document/<int:doc_id>')
def view_document(doc_id):
    """Document viewer with annotation interface."""
    conn = get_db()
    
    document = conn.execute(
        'SELECT * FROM documents WHERE id = ?', (doc_id,)
    ).fetchone()
    
    if not document:
        return "Document not found", 404
    
    annotations = conn.execute('''
        SELECT a.*, l.name as label_name, l.color as label_color
        FROM annotations a
        LEFT JOIN labels l ON a.label_id = l.id
        WHERE a.document_id = ?
        ORDER BY a.start_offset
    ''', (doc_id,)).fetchall()
    
    labels = conn.execute('SELECT * FROM labels ORDER BY name').fetchall()
    
    # Get adjacent documents for navigation
    prev_doc = conn.execute('''
        SELECT id, filename FROM documents 
        WHERE filename < ? ORDER BY filename DESC LIMIT 1
    ''', (document['filename'],)).fetchone()
    
    next_doc = conn.execute('''
        SELECT id, filename FROM documents 
        WHERE filename > ? ORDER BY filename LIMIT 1
    ''', (document['filename'],)).fetchone()
    
    conn.close()
    
    return render_template('document.html',
                         document=document,
                         annotations=annotations,
                         labels=labels,
                         prev_doc=prev_doc,
                         next_doc=next_doc)

@app.route('/api/annotation', methods=['POST'])
def create_annotation():
    """Create new annotation."""
    data = request.json
    conn = get_db()
    
    cursor = conn.execute('''
        INSERT INTO annotations 
        (document_id, label_id, start_offset, end_offset, highlighted_text, comment, note)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        data['document_id'],
        data.get('label_id'),
        data['start_offset'],
        data['end_offset'],
        data['highlighted_text'],
        data.get('comment', ''),
        data.get('note', '')
    ))
    
    annotation_id = cursor.lastrowid
    conn.commit()
    
    # Get the full annotation with label info
    annotation = conn.execute('''
        SELECT a.*, l.name as label_name, l.color as label_color
        FROM annotations a
        LEFT JOIN labels l ON a.label_id = l.id
        WHERE a.id = ?
    ''', (annotation_id,)).fetchone()
    
    conn.close()
    
    return jsonify({
        'id': annotation['id'],
        'label_name': annotation['label_name'],
        'label_color': annotation['label_color'],
        'highlighted_text': annotation['highlighted_text'],
        'comment': annotation['comment'],
        'note': annotation['note']
    })

@app.route('/api/annotation/<int:ann_id>', methods=['PUT'])
def update_annotation(ann_id):
    """Update existing annotation."""
    data = request.json
    conn = get_db()
    
    conn.execute('''
        UPDATE annotations 
        SET label_id = ?, comment = ?, note = ?
        WHERE id = ?
    ''', (
        data.get('label_id'),
        data.get('comment', ''),
        data.get('note', ''),
        ann_id
    ))
    
    conn.commit()
    conn.close()
    
    return jsonify({'success': True})

@app.route('/api/annotation/<int:ann_id>', methods=['DELETE'])
def delete_annotation(ann_id):
    """Delete annotation."""
    conn = get_db()
    conn.execute('DELETE FROM annotations WHERE id = ?', (ann_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/labels', methods=['GET'])
def get_labels():
    """Get all labels."""
    conn = get_db()
    labels = conn.execute('SELECT * FROM labels ORDER BY name').fetchall()
    conn.close()
    return jsonify([dict(l) for l in labels])

@app.route('/api/labels', methods=['POST'])
def create_label():
    """Create new label."""
    data = request.json
    conn = get_db()
    
    try:
        cursor = conn.execute(
            'INSERT INTO labels (name, color, description) VALUES (?, ?, ?)',
            (data['name'], data.get('color', '#FFD700'), data.get('description', ''))
        )
        label_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return jsonify({'id': label_id, 'name': data['name'], 'color': data.get('color', '#FFD700')})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'error': 'Label already exists'}), 400

@app.route('/api/labels/<int:label_id>', methods=['PUT'])
def update_label(label_id):
    """Update label."""
    data = request.json
    conn = get_db()
    
    conn.execute('''
        UPDATE labels SET name = ?, color = ?, description = ?
        WHERE id = ?
    ''', (data['name'], data['color'], data.get('description', ''), label_id))
    
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/labels/<int:label_id>', methods=['DELETE'])
def delete_label(label_id):
    """Delete label (sets annotation label_id to NULL)."""
    conn = get_db()
    conn.execute('UPDATE annotations SET label_id = NULL WHERE label_id = ?', (label_id,))
    conn.execute('DELETE FROM labels WHERE id = ?', (label_id,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/export/excel')
def export_excel():
    """Export all annotations to Excel."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    
    conn = get_db()
    
    # Get all annotations with document and label info
    annotations = conn.execute('''
        SELECT 
            a.id,
            d.filename as document,
            l.name as label,
            l.color as label_color,
            a.highlighted_text,
            a.comment,
            a.note,
            a.start_offset,
            a.end_offset,
            a.created_at
        FROM annotations a
        JOIN documents d ON a.document_id = d.id
        LEFT JOIN labels l ON a.label_id = l.id
        ORDER BY d.filename, a.start_offset
    ''').fetchall()
    
    conn.close()
    
    # Create workbook
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Coding Data"
    
    # Headers
    headers = ['ID', 'Document', 'Label', 'Highlighted Text', 'Comment', 'Note', 
               'Start Position', 'End Position', 'Created At', 'Document Link']
    
    # Style headers
    header_fill = PatternFill(start_color='2C3E50', end_color='2C3E50', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border
    
    # Data rows
    for row_idx, ann in enumerate(annotations, 2):
        ws.cell(row=row_idx, column=1, value=ann['id'])
        ws.cell(row=row_idx, column=2, value=ann['document'])
        
        label_cell = ws.cell(row=row_idx, column=3, value=ann['label'] or '(No label)')
        if ann['label_color']:
            # Convert hex color to fill
            color = ann['label_color'].replace('#', '')
            label_cell.fill = PatternFill(start_color=color, end_color=color, fill_type='solid')
        
        ws.cell(row=row_idx, column=4, value=ann['highlighted_text'])
        ws.cell(row=row_idx, column=5, value=ann['comment'])
        ws.cell(row=row_idx, column=6, value=ann['note'])
        ws.cell(row=row_idx, column=7, value=ann['start_offset'])
        ws.cell(row=row_idx, column=8, value=ann['end_offset'])
        ws.cell(row=row_idx, column=9, value=ann['created_at'])
        
        # Create internal link to document view
        link_cell = ws.cell(row=row_idx, column=10, value=f"View in app")
        # Note: Excel hyperlinks to localhost won't work when file is opened elsewhere
        # This is informational only
        
        # Apply borders
        for col in range(1, 11):
            ws.cell(row=row_idx, column=col).border = thin_border
    
    # Adjust column widths
    column_widths = [8, 25, 15, 50, 40, 40, 12, 12, 20, 15]
    for col, width in enumerate(column_widths, 1):
        ws.column_dimensions[get_column_letter(col)].width = width
    
    # Create summary sheet
    ws_summary = wb.create_sheet("Summary")
    
    # Label frequency summary
    ws_summary['A1'] = 'Label Summary'
    ws_summary['A1'].font = Font(bold=True, size=14)
    
    ws_summary['A3'] = 'Label'
    ws_summary['B3'] = 'Count'
    ws_summary['A3'].font = header_font
    ws_summary['B3'].font = header_font
    ws_summary['A3'].fill = header_fill
    ws_summary['B3'].fill = header_fill
    
    conn = get_db()
    label_counts = conn.execute('''
        SELECT l.name, l.color, COUNT(a.id) as count
        FROM labels l
        LEFT JOIN annotations a ON l.id = a.label_id
        GROUP BY l.id
        ORDER BY count DESC
    ''').fetchall()
    conn.close()
    
    for row_idx, lc in enumerate(label_counts, 4):
        ws_summary.cell(row=row_idx, column=1, value=lc['name'])
        ws_summary.cell(row=row_idx, column=2, value=lc['count'])
        if lc['color']:
            color = lc['color'].replace('#', '')
            ws_summary.cell(row=row_idx, column=1).fill = PatternFill(
                start_color=color, end_color=color, fill_type='solid'
            )
    
    ws_summary.column_dimensions['A'].width = 20
    ws_summary.column_dimensions['B'].width = 10
    
    # Save
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    filename = f'qualitative_export_{timestamp}.xlsx'
    filepath = EXPORTS_DIR / filename
    wb.save(filepath)
    
    return send_file(filepath, as_attachment=True, download_name=filename)

@app.route('/labels')
def labels_page():
    """Label management page."""
    conn = get_db()
    
    labels = conn.execute('''
        SELECT l.*, COUNT(a.id) as usage_count
        FROM labels l
        LEFT JOIN annotations a ON l.id = a.label_id
        GROUP BY l.id
        ORDER BY l.name
    ''').fetchall()
    
    conn.close()
    return render_template('labels.html', labels=labels)

if __name__ == '__main__':
    init_db()
    print("\n" + "="*60)
    print("  Qualitative Data Coder")
    print("="*60)
    print(f"\n  📁 Place your documents in: {DATA_DIR}")
    print(f"  📊 Exports will be saved to: {EXPORTS_DIR}")
    print(f"\n  🌐 Open in browser: http://localhost:5000")
    print("\n" + "="*60 + "\n")
    app.run(debug=True, port=5000)
